
    <div class="card my-3 col-md-12">
        <div class="card-body">
            <h4>New Location/Branch</h4> <br>
            <form class="form-material" action="{{ route('locations.new') }}" method="POST">
                {{ csrf_field() }}
                <div class="row clearfix">
                    <div class="col-sm-6">
                        <div class="form-group form-float form-group-sm">
                            <div class="form-line">
                                <input type="text" class="form-control" name="locName" />
                                <label class="form-label">Location/Branch Name</label>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <select class="custom-select select2" required name="residentpastor" id="residentpastor">
                            <option value="">Resident Pastor</option>
                            @foreach($pastors as $pst)
                            <option value="{{$pst->id}}">{{$pst->pst_name}}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="row clearfix">
                    <div class="col-sm-4">
                        <div class="form-group form-float form-group-sm">
                            <div class="form-line">
                                <input type="text" class="form-control" name="locMail" />
                                <label class="form-label">eMail Address</label>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="form-group form-float form-group-sm">
                            <div class="form-line">
                                <input type="text" class="form-control" name="phone1" placeholder="08012345678" pattern="(0)([7,8,9])([0,1])(\d{8})"/>
                                <label class="form-label">Phone No 1</label>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="form-group form-float form-group-sm">
                            <div class="form-line">
                                <input type="text" class="form-control" name="phone2" />
                                <label class="form-label">Phone No 2</label>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row clearfix">
                     <div class="col-sm-4">
                        <select class="custom-select select2" required name="zone" id="zone">
                            <option value="">Select Host Zone</option>
                            @foreach($zones as $zone)
                            <option value="{{$zone->id}}">{{$zone->zone_name}}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="col-sm-4">
                        <select class="custom-select select2" required name="state" id="state">
                            <option value="">Select Host State</option>
                            @foreach($states as $state)
                            <option value="{{$state->id}}">{{$state->state}}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-sm-4">
                        <select class="form-control" required name="lga" id="lga">
                        </select>
                    </div>
                </div>
                <br>
                <div class="row clearfix">
                    <div class="col-sm-12">
                        <div class="form-group form-float form-group-sm">
                            <div class="form-line">
                                <textarea class="form-control" rows="2" name="locAddress"></textarea>
                                <label class="form-label">Location Addres</label>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-sm-12" align="center">
                    <button type="submit" class="btn btn-primary btn-sm mt-2"> Create New Location</button>
                </div>
            </form>
        </div>
    </div>
<br>
<hr>