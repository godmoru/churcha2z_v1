<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class IncomeReportEdited extends Model
{
    //
}
