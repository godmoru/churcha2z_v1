<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class Mstatus extends Model {

	//

}
