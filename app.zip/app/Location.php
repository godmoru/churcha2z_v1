<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class Location extends Model {
protected $table = 'locations';
	//
	public function loc_state()
	{
		return $this->BelongsTo('App\State', 'id_state', 'id');
	}
	
	public function country()
	{
		return $this->BelongsTo('App\Country', 'country_id', 'id');
	}
	

	public function lcolga()
	{
		return $this->BelongsTo('App\Lga', 'id_lga', 'id');
	}

	public function loc_zone()
	{
		return $this->BelongsTo('App\GeoPolZone', 'id_zone', 'id');
	}

	public function loc_psts()
	{
		return $this->HasMany('App\Pastors', 'pastor_id', 'id');
	}
	public function loc_members()
	{
		return $this->HasMany('App\Member', 'location_id', 'id');
	}
	public function loc_converts()
	{
		return $this->HasMany('App\People', 'location_id', 'id');
	}
	public function get_attendance()
	{
		return $this->HasMany('App\Attendance', 'location_id', 'location_id');
	}
	public function get_loc_pst()
	{
		//return Pastors::where("id", "=", $this->pastor_id)->get();
		return $this->belongsTo('App\Pastors', 'pastor_id', 'id');
	}
	public function locmembers()
	{
		return People::where('location_id', '=', $this->id)->get();
	}

	public function get_pst_loc()
	{
		return $this->BelongsTo('App\Pastors', 'id', 'pastor_id');
		//return Pastors::Where("id", "=", $this->pastor_id)->get();
	}

	public function getfirsttimers()
	{
		return $this->hasMany(People::class)->where('people_category_id',1);
	}
	public function getnewconverts()
	{
		return $this->hasMany(People::class)->where('people_category_id',2);

	}
	public function getpeoplefromevangelism()
	{
		return $this->hasMany(People::class)->where('people_category_id',3);
	}

	public function getcrusadeoutreachpeople()
	{
		return $this->hasMany(People::class)->where('people_category_id',5);
	}


	public function locPsts()
	{
		return $this->hasMany('App\Pastors', 'id', 'pastor_id');
	}
	public function loc_pstx()
	{
		return $this->hasMany('App\Pastors', 'id_pst', 'id');		
	}

	// Home Churches \\

	public function gethomecells()
	{
		return $this->hasMany(Homecell::class);		
	}
	// End Home Churches \\

	// Establishment Classes Foundation and Maturity (DLTC Classes) \\

	public function getTotalFClass()
	{
		return $this->hasMany('App\People', 'location_id', 'id')->where('fclass_status', 1);		
		// return People::where("fclass_status", "=",1)->where('location_id', '=', $this->id)->get();

	}

	public function getTotalDLTC()
	{
		return $this->hasMany('App\People', 'location_id', 'id')->where('dltc_status', 1);		
		// return People::where("fclass_status", "=",1)->where('location_id', '=', $this->id)->get();

	}

	// End Home Churches \\

	public function getservicesettings()
	{
		return $this->hasMany('App\LocationServiceSetting', 'location_id', 'id');		
	}
	
	/** Weekly Report**/ 

	public function weeklyreports()
	{
		return $this->hasMany('App\WeeklyReport', 'location_id', 'id');		
	}
	/** End Weekly Report**/ 
	
	public function getPostingHistory()
	{
		return $this->hasMany('App\PastorLocationHistory', 'location_id', 'id');		
	}
    
	public function parentLoc()
	{
		return $this->belongsTo('\App\Location', 'parent_location_id', 'id');
	}

	public function locPlanted()
	{
		return $this->hasMany('\App\Location', 'parent_location_id', 'id');
	}
	public function plantingPst()
	{
		return $this->belongsTo('\App\Pastor', 'presiding_pastor_id', 'id');
	}
	
	public function poineeringPst()
	{
		return $this->belongsTo('\App\Pastor', 'first_resident_pastor_id', 'id');
	}

	public function firstResPst()
	{
		return $this->belongsTo('\App\Pastor', 'first_resident_pastor_id', 'id');
	}
	
	public function asstPst()
	{
		return $this->belongsTo('\App\Pastor', 'assistant_pastor_id', 'id');
	}

}
