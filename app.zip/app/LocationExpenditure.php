<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LocationExpenditure extends Model
{
    //
}
