<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ClassStatus extends Model
{
    //
}
