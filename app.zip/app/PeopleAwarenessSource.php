<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PeopleAwarenessSource extends Model
{
    //
}
