<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SpecialAttendanceHead extends Model
{
    //
}
