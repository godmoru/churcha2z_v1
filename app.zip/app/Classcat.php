<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class Classcat extends Model {
	protected $table = 'class_cat';

	//

}
