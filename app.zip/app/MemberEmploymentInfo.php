<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MemberEmploymentInfo extends Model
{
    //
}
