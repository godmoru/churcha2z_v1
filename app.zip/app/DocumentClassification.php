<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DocumentClassification extends Model
{
    //
}
