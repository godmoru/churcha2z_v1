<div class="modal fade bt-white" id="vomnth" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title text-uppercase" id="myModalLabel">Month Income History </h4>
            </div>
            <div class="modal-body">
                
               <table class="table table-bordered table-hover" >
                    <thead>
                        <tr>
                            <th style="text-align: center; text-transform: uppercase;">Timestamp</th>
                            <th style="text-align: center; text-transform: uppercase;">Cash</th>
                            <th style="text-align: center; text-transform: uppercase;">POS/Transfer</th>
                            <th style="text-align: center; text-transform: uppercase;">Cheques</th>
                            <th style="text-align: center; text-transform: uppercase;">Total</th> 
                        </tr>
                    </thead>
                    <tbody>
                        
                    <tr>
                        
                    </tr>

                    <tr>
                    <td colspan="4">Grand Total</td>
                    
                    <td align="center">
                        <div class="form-group form-float form-group-sm text-bolder h3">
                            <b>&#8358; <span id="grandT"></span></b>
                        </div>
                    </td>
                </tr>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
