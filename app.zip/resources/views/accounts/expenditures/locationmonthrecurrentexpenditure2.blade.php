
@extends('layouts.master')

@section('content')
<div class="row my-3 col-md-12">
    <div class="col-md-8">
        
        <div class=" card b-0">
            <div class="card-header white">
                <i class="icon-home 2x blue-text"></i> <strong class="text-uppercase">Month Recurrent Expenditure </strong> 
                <div class="pull-right" align="right">

                    <div class="btn-group" >
                        <button class="btn btn-success btn-xs btn-flat btn-block ">Submit Expenditure Records</button>
                        <button class="btn btn-success btn-xs dropdown-toggle" data-toggle="dropdown"><span class="caret"></span></button>
                        <ul class="dropdown-menu">
                            <li><a class="btn" data-toggle="modal" data-target="#newexp" aria-expanded="false" aria-controls="collapseExample">New Expenditure</a></li>
                            <!--<li><a class="btn" data-toggle="modal" data-target="#newuncatexp" aria-expanded="false" aria-controls="collapseExample">New Uncategorized Expenditure</a></li>-->
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card-body ">
                <table class="table table-bordered table-hover" data-options='{ "paging": false; "searching":false}'>
                  <thead>
                    <tr>
                        <th width="2%" style="text-align: center; text-transform: uppercase;">S/No</th>
                        <th width="25%" style="text-align: center; text-transform: uppercase;">Type Name</th>
                        <th width="8%" style="text-align: center; text-transform: uppercase;">Month Total(&#8358;)</th>
                        </tr>
                    </thead>
                     <tbody>
                        <tr class="odd gradeX">
                        @foreach($expTypes as $count => $type)
                        
                        @php
                            if(count(\App\LocationExpenditure::where('location_id', \Auth::user()->location_id)->get()) > 0){
                            $locVal = isset(\App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', $type->id)->latest()->first()->amount) ? \App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', $type->id)->latest()->first()->amount : 0;
                            }else{
                            $locVal = 0;
                            }
                            $expt9 = isset(\App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 9)->latest()->first()->amount) ? \App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 9)->latest()->first()->amount : 0;
                            $expt10 = isset(\App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 10)->latest()->first()->amount) ? \App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 10)->latest()->first()->amount : 0;
                            $expt11 = isset(\App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 11)->latest()->first()->amount) ? \App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 11)->latest()->first()->amount : 0;
                            $expt12 = isset(\App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 12)->latest()->first()->amount) ? \App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 12)->latest()->first()->amount : 0;
                            $expt13 = isset(\App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 13)->latest()->first()->amount) ? \App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 13)->latest()->first()->amount : 0;
                            $expt14 = isset(\App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 14)->latest()->first()->amount) ? \App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 14)->latest()->first()->amount : 0;
                            $expt15 = isset(\App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 15)->latest()->first()->amount) ? \App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 15)->latest()->first()->amount : 0;
                            $expt16 = isset(\App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 16)->latest()->first()->amount) ? \App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 16)->latest()->first()->amount : 0;
                            $expt17 = isset(\App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 17)->latest()->first()->amount) ? \App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 17)->latest()->first()->amount : 0;
                            $expt18 = isset(\App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 18)->latest()->first()->amount) ? \App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 18)->latest()->first()->amount : 0;
                            $expt19 = isset(\App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 19)->latest()->first()->amount) ? \App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 19)->latest()->first()->amount : 0;
                            $expt20 = isset(\App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 20)->latest()->first()->amount) ? \App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 20)->latest()->first()->amount : 0;
                            $expt21 = isset(\App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 21)->latest()->first()->amount) ? \App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 21)->latest()->first()->amount : 0;
                            $expt22 = isset(\App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 22)->latest()->first()->amount) ? \App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 22)->latest()->first()->amount : 0;
                            $expt23 = isset(\App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 23)->latest()->first()->amount) ? \App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 23)->latest()->first()->amount : 0;
                            $expt24 = isset(\App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 24)->latest()->first()->amount) ? \App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 24)->latest()->first()->amount : 0;
                            $expt25 = isset(\App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 25)->latest()->first()->amount) ? \App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', 25)->latest()->first()->amount : 0;

                            
                        @endphp
                            <td>{{ ++$count }}</td>  
                            <input type="hidden" name="typeId[]" value="{{$type->id}}">
                            <td><b>{{ $type->name }}</b></td>
                            <td align="right">
                                @if(count(\App\LocationExpenditure::where('location_id', \Auth::user()->location_id)->get()) > 0)
                                    {{ number_format($locVal, 2) }}
                                @else
                                0.00
                                @endif
                            </td>
                        </tr>
                        @endforeach
                        
                        <tr>
                            <td colspan="2" style="font-weight: bold;"> Month Sub Total <small style="color: red;"> Categorized Expenditures</small> </td>
                            <td align="right" style="font-weight: bold;"> &#8358;
                            {{number_format(($expt9 + $expt10 +$expt11 + $expt12 + $expt13 + $expt14 + $expt15 + $expt16 + $expt17 + $expt18 + $expt19 + $expt20 + $expt21 + $expt22+$expt23+$expt24+$expt25),2)}}
                            </td>
                        </tr>
                        
                        <!--<tr>-->
                        <!--    <td colspan="2" style="font-weight: bold;"> Month Sub Total <small style="color: red;"> Uncategorized Expenditures</small> </td>-->
                        <!--    <td align="right" style="font-weight: bold;"> &#8358;-->
                        <!--        @if(count(\App\LocationExpenditure::where('location_id', \Auth::user()->location_id)->get()) > 0)-->
                        <!--            {{ number_format(\App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', '999999000')->sum('amount'), 2) }}-->
                        <!--            @else-->
                        <!--            0.00-->
                        <!--        @endif   -->
                        <!--    </td>-->
                        <!--</tr>-->
                        
                        
                        <!--<tr>-->
                        <!--    <td colspan="2" style="font-weight: bold;">Grand Monthly Total</td>-->
                        <!--    <td align="right" style="font-weight: bold;"> &#8358;-->
                        <!--        @if(count(\App\LocationExpenditure::where('location_id', \Auth::user()->location_id)->get()) > 0)-->
                        <!--            {{ number_format(($expt9 + $expt10 +$expt11 + $expt12 + $expt13 + $expt14 + $expt15 + $expt16 + $expt18 + $expt19 + $expt20 + $expt21 + $expt22) + \App\LocationExpenditure::where('year', date('Y'))->where('month', date('m'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', '999999000')->sum('amount'), 2) }}-->
                        <!--            @else-->
                        <!--            0.00-->
                        <!--            @endif   -->
                        <!--    </td>-->
                        <!--</tr>-->
                    </tbody>
              </table>                
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card b-0">
            <div class="card-header white text-uppercase" >
                <!--Month's Uncategorised Expenditures-->
            </div>
            <div class="card-body">
              <!--  <table class="table table-bordered table-hover" data-options='{ "paging": false; "searching":false}'>-->
              <!--    <thead>-->
              <!--      <tr>-->
              <!--          <th width="2%" style="text-align: center; text-transform: uppercase;">S/No</th>-->
              <!--          <th width="25%" style="text-align: center; text-transform: uppercase;">Type Name</th>-->
              <!--          <th width="8%" style="text-align: center; text-transform: uppercase;">Month Total (&#8358;)</th>-->
              <!--          </tr>-->
              <!--      </thead>-->
              <!--       <tbody>-->
                        
              <!--          <tr class="odd gradeXr">-->
              <!--          @foreach(\App\LocationExpenditure::where('expenditure_type_id', 999999000)->where('location_id', \Auth::user()->location_id)->groupBy('expenditure_type_other_name')->get() as $count => $type)-->
              <!--              <td>{{ ++$count }}</td>  -->
              <!--              <input type="hidden" name="typeId[]" value="{{$type->id}}">-->
              <!--              <td> <b>{{ isset($type) ? $type->expenditure_type_other_name : "" }}</b></td>-->
              <!--              <td align="right">-->
                                
              <!--                  {{isset($type) ? number_format($type->amount, 2) : "0.00"}}-->
              <!--              </td>-->
              <!--          </tr>-->
              <!--          @endforeach-->
              <!--          <tr>-->
              <!--              <td colspan="2" style="font-weight: bold;">Month Total</td>-->
              <!--              <td align="right" style="font-weight: bold;"> &#8358; {{number_format(\App\LocationExpenditure::where('year', date('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', '999999000')->sum('amount'), 0) }}</td>-->
              <!--          </tr>-->
              <!--      </tbody>-->
              <!--</table>  -->
            </div>
        </div>
    </div>
</div>
@include('accounts.expenditures.newrecurrentexpenditure')
@include('accounts.expenditures.newuncatrecurrent')
@endsection
@section('scripts')
<script type="text/javascript">
    function sumup() {
        $("#Tamount").on('input', '.amount', function () {
       var Asum = 0;
       $("#Tamount .amount").each(function () {
           var amount = $(this).val();
           if ($.isNumeric(amount)) {
              Asum += parseFloat(amount);
              }                  
            });
              $("#Atotal").text(Asum.toFixed(0).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,"));
        });
    }
    
    function summore() {
        $("#expUncat2").on('input', '.amount', function () {
       var Asum = 0;
       $("#expUncat2 .amount").each(function () {
           var amount = $(this).val();
           if ($.isNumeric(amount)) {
              Asum += parseFloat(amount);
              }                  
            });
              $("#Utotal2").text(Asum.toFixed(0).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,"));
        });
    }
    
</script>
@endsection