@extends('layouts.master')

@section('content')
<div class="row my-3 col-md-12">
    <div class="col-md-12">
        
        <div class=" card b-0">
            <div class="card-header white">
                <i class="icon-home 2x blue-text"></i> <strong class="text-uppercase">Year Recurrent Expenditure </strong> 
                <div class="pull-right" align="right"><a data-toggle="modal" data-target="#newexp" aria-expanded="false" aria-controls="collapseExample" class="btn btn-primary btn-xs btn-round"> New Expenditure</a></div>
            </div>
            <div class="card-body slimScroll">
                <table class="table table-bordered table-hover" data-options='{ "paging": false; "searching":false}'>
                  <thead>
                    <tr>
                        <th width="2%" style="text-align: center; text-transform: uppercase;">S/No</th>
                        <th width="25%" style="text-align: center; text-transform: uppercase;">Type Name</th>
                        <th width="8%" style="text-align: center; text-transform: uppercase;">Jan</th>
                        <th width="8%" style="text-align: center; text-transform: uppercase;">Feb</th>
                        <th width="8%" style="text-align: center; text-transform: uppercase;">Mar</th>
                        <th width="8%" style="text-align: center; text-transform: uppercase;">Apr</th>
                        <th width="8%" style="text-align: center; text-transform: uppercase;">May</th>
                        <th width="8%" style="text-align: center; text-transform: uppercase;">Jun</th>
                        <th width="8%" style="text-align: center; text-transform: uppercase;">Jul</th>
                        <th width="8%" style="text-align: center; text-transform: uppercase;">Aug</th>
                        <th width="8%" style="text-align: center; text-transform: uppercase;">Sept</th>
                        <th width="8%" style="text-align: center; text-transform: uppercase;">Oct</th>
                        <th width="8%" style="text-align: center; text-transform: uppercase;">Nov</th>
                        <th width="8%" style="text-align: center; text-transform: uppercase;">Dec</th>
                        <th style="text-align: center; text-transform: uppercase;">Total</th>
                        </tr>
                    </thead>
                     <tbody>
                            <tr class="odd gradeX">
                            @foreach($expTypes as $count => $type)
                                <td>{{ ++$count }}</td>  
                                <input type="hidden" name="typeId[]" value="{{$type->id}}">
                                <td><a href="{{route('classes.one', \Crypt::encrypt(1)) }}"> <b>{{ $type->name }}</b></a></td>
                                <td align="center">{{
                                    number_format(\App\LocationExpenditure::where('year', \Carbon\Carbon::now('Y'))->where('month', 1)->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', $type->id)->sum('amount'), 0) }}</td>
                                    <td align="center">{{
                                    number_format(\App\LocationExpenditure::where('year', \Carbon\Carbon::now('Y'))->where('month', 2)->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', $type->id)->sum('amount'), 0) }}</td>
                                    <td align="center">{{
                                    number_format(\App\LocationExpenditure::where('year', \Carbon\Carbon::now('Y'))->where('month', 3)->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', $type->id)->sum('amount'), 0) }}</td>
                                    <td align="center">{{
                                    number_format(\App\LocationExpenditure::where('year', \Carbon\Carbon::now('Y'))->where('month', 4)->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', $type->id)->sum('amount'), 0) }}</td>

                                <td align="center">{{
                                    number_format(\App\LocationExpenditure::where('year', \Carbon\Carbon::now('Y'))->where('month', 5)->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', $type->id)->sum('amount'), 0) }}</td>
                                
                                <td align="center">{{
                                    number_format(\App\LocationExpenditure::where('year', \Carbon\Carbon::now('Y'))->where('month', 6)->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', $type->id)->sum('amount'), 0) }}</td>
                                    <td align="center">{{
                                    number_format(\App\LocationExpenditure::where('year', \Carbon\Carbon::now('Y'))->where('month', 7)->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', $type->id)->sum('amount'), 0) }}</td>
                                    <td align="center">{{
                                    number_format(\App\LocationExpenditure::where('year', \Carbon\Carbon::now('Y'))->where('month', 8)->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', $type->id)->sum('amount'), 0) }}</td>
                                    <td align="center">{{
                                    number_format(\App\LocationExpenditure::where('year', \Carbon\Carbon::now('Y'))->where('month', 9)->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', $type->id)->sum('amount'), 0) }}</td>
                                    <td align="center">{{
                                    number_format(\App\LocationExpenditure::where('year', \Carbon\Carbon::now('Y'))->where('month', 10)->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', $type->id)->sum('amount'), 0) }}</td>
                                    <td align="center">{{
                                    number_format(\App\LocationExpenditure::where('year', \Carbon\Carbon::now('Y'))->where('month', 11)->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', $type->id)->sum('amount'), 0) }}</td>
                                    <td align="center">{{
                                    number_format(\App\LocationExpenditure::where('year', \Carbon\Carbon::now('Y'))->where('month', 12)->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', $type->id)->sum('amount'), 0) }}</td>
                                <td align="center">{{
                                    number_format(\App\LocationExpenditure::where('year', \Carbon\Carbon::now('Y'))->where('location_id', \Auth::user()->location_id)->where('expenditure_type_id', $type->id)->sum('amount'), 0) }}</td>
                            </tr>
                        @endforeach
                        <tr>
                            <td colspan="2" style="font-weight: bold;">Grand Monthly Total</td>
                            <td align="center" style="font-weight: bold;">{{
                                    number_format(\App\LocationExpenditure::where('year', \Carbon\Carbon::now('Y'))->where('month', 1)->where('location_id', \Auth::user()->location_id)->whereBetween('expenditure_type_id', [9,22])->sum('amount'), 0) }}</td>
                            <td align="center" style="font-weight: bold;">{{
                                    number_format(\App\LocationExpenditure::where('year', \Carbon\Carbon::now('Y'))->where('month', 2)->where('location_id', \Auth::user()->location_id)->whereBetween('expenditure_type_id', [9,22])->sum('amount'), 0) }}</td>
                            <td align="center" style="font-weight: bold;">{{
                                    number_format(\App\LocationExpenditure::where('year', \Carbon\Carbon::now('Y'))->where('month', 3)->where('location_id', \Auth::user()->location_id)->whereBetween('expenditure_type_id', [9,22])->sum('amount'), 0) }}</td>
                            <td align="center" style="font-weight: bold;">{{
                                    number_format(\App\LocationExpenditure::where('year', \Carbon\Carbon::now('Y'))->where('month', 4)->where('location_id', \Auth::user()->location_id)->whereBetween('expenditure_type_id', [9,22])->sum('amount'), 0) }}</td>
                            <td align="center" style="font-weight: bold;">{{
                                    number_format(\App\LocationExpenditure::where('year', \Carbon\Carbon::now('Y'))->where('month', 5)->where('location_id', \Auth::user()->location_id)->whereBetween('expenditure_type_id', [9,22])->sum('amount'), 0) }}</td>
                            <td align="center" style="font-weight: bold;">{{
                                    number_format(\App\LocationExpenditure::where('year', \Carbon\Carbon::now('Y'))->where('month', 6)->where('location_id', \Auth::user()->location_id)->whereBetween('expenditure_type_id', [9,22])->sum('amount'), 0) }}</td>
                            <td align="center" style="font-weight: bold;">{{
                                    number_format(\App\LocationExpenditure::where('year', \Carbon\Carbon::now('Y'))->where('month', 7)->where('location_id', \Auth::user()->location_id)->whereBetween('expenditure_type_id', [9,22])->sum('amount'), 0) }}</td>
                            <td align="center" style="font-weight: bold;">{{
                                    number_format(\App\LocationExpenditure::where('year', \Carbon\Carbon::now('Y'))->where('month', 8)->where('location_id', \Auth::user()->location_id)->whereBetween('expenditure_type_id', [9,22])->sum('amount'), 0) }}</td>
                            <td align="center" style="font-weight: bold;">{{
                                    number_format(\App\LocationExpenditure::where('year', \Carbon\Carbon::now('Y'))->where('month', 9)->where('location_id', \Auth::user()->location_id)->whereBetween('expenditure_type_id', [9,22])->sum('amount'), 0) }}</td>
                            <td align="center" style="font-weight: bold;">{{
                                    number_format(\App\LocationExpenditure::where('year', \Carbon\Carbon::now('Y'))->where('month', 10)->where('location_id', \Auth::user()->location_id)->whereBetween('expenditure_type_id', [9,22])->sum('amount'), 0) }}</td>
                            <td align="center" style="font-weight: bold;">{{
                                    number_format(\App\LocationExpenditure::where('year', \Carbon\Carbon::now('Y'))->where('month', 11)->where('location_id', \Auth::user()->location_id)->whereBetween('expenditure_type_id', [9,22])->sum('amount'), 0) }}</td>
                            <td align="center" style="font-weight: bold;">{{
                                    number_format(\App\LocationExpenditure::where('year', \Carbon\Carbon::now('Y'))->where('month', 12)->where('location_id', \Auth::user()->location_id)->whereBetween('expenditure_type_id', [9,22])->sum('amount'), 0) }}</td>
                           
                            <td align="center" style="font-weight: bold;">{{
                                    number_format(\App\LocationExpenditure::where('year', \Carbon\Carbon::now('Y'))->where('location_id', \Auth::user()->location_id)->whereBetween('expenditure_type_id', [9,22])->sum('amount'), 0) }}</td>
                        </tr>
                    </tbody>
              </table>                
            </div>
        </div>
    </div>
</div>
@include('accounts.expenditures.newcapexpenditure')

@endsection
@section('scripts')
<script type="text/javascript">
    function sumup() {
        $("#Tamount").on('input', '.amount', function () {
       var Asum = 0;
       $("#Tamount .amount").each(function () {
           var amount = $(this).val();
           if ($.isNumeric(amount)) {
              Asum += parseFloat(amount);
              }                  
            });
              $("#Atotal").text(Asum.toFixed(0).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,"));
        });
    }
</script>
@endsection