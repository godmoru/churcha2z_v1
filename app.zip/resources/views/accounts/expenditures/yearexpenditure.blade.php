@extends('layouts.master')

@section('content')
<div class="row my-3 ">
    <div class="col-md-12">
        
        <div class=" card b-0">
            <div class="card-header white">
                <i class="icon-calendar 2x blue-text"></i> <strong class="text-uppercase"> Expenditures by locations </strong> 
                <div class="pull-right" align="right">
                    <a href="{{ route('expenditure.printlocationsyear', \Crypt::encrypt(58398)) }}" class="btn btn-xs btn-info" style="color: white;"> <i class="icon-print"></i> Print Report</a>
                    <a data-toggle="modal" data-target="#oyear" class="btn btn-warning btn-xs"> <i class="icon-search"></i> View Other Year</a>
                    <a data-toggle="modal" data-target="#vmonth" class="btn btn-success btn-xs"> <i class="icon-search"></i>Query Reports</a>


                    <!-- <a data-toggle="modal" data-target="#fetchLocationData" class="btn btn-xs btn-success"> <i class="icon-download"></i> Get By Location/Period</a> -->
                </div>
            </div>
            <div class="card-body">
                

                <table id="example2" class="table table-bordered table-hover" data-options='{ "paging": false; "searching":false}'>
                    <thead>
                        <tr>
                            <th colspan="16" width="20%" style="text-align: center; text-transform: uppercase; font-weight: bold; font-size: 16px;" >
                                <img src="{{asset('img/dunamis.png')}}" style="width: 110px; height: 90px"><br>
                                locations Expenditure for {{ date('Y')}}
                            </th>
                        </tr>
                        <tr>
                            <td  colspan="" rowspan="2" style="text-align: left; text-transform: uppercase; font-weight: bold;">
                                <br>Branch Name
                            </td>
                            <td colspan="2" style="text-align: center; text-transform: uppercase; font-weight: bold;"> Grand Summary</td>

                        </tr>

                        <tr>
                            <th width="8%" style="text-align: center; text-transform: uppercase;">Total Expenditure &nbsp; </th>
                            <td width="15%" style="text-align: center; text-transform: uppercase; font-weight: bold;" rowspan="2" colspan="">Remarks</td>
                        </tr>
                        <tr>

                        </tr>
                    </thead>
                    <tbody>
                        @foreach($locations as $location)
                        <tr>
                            <td width="15%" rowspan="" style="text-transform: uppercase; font-weight: bold">{{$location->loc_name}}</td>
                            <td align="right">
                            {{
                                number_format(( \App\LocationExpenditure::where('year', date('Y'))->where('location_id', $location->id)->sum('amount')), 2) 
                            }}
                            </td>
                            <td>
                                
                            </td>

                        </tr>
                        
                        @endforeach
                        <tr>
                        <td style="text-transform: uppercase; font-weight: bolder; font-size: 1.5em;">Grand Total</td>
                        <td style="font-size: 1.5em; text-align: right; font-weight: bold;"> &#8358; {{
                            number_format(( \App\LocationExpenditure::where('year', date('Y'))->sum('amount')), 2) 
                        }}</td>
                        <td></td>
                    </tr>
                    </tbody>
                </table>

            </div>
        </div>
    </div>

</div>
@include('accounts.income.modals.viewotheryear')
@include('accounts.income.modals.viewmonthly')

@endsection