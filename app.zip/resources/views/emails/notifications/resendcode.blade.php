<!DOCTYPE html>
<html>
<head>
  <title>
    Code Generation
  </title>
</head>
<body>
  <p style="font-size:14px; text-decoration:none; color:#3a3d41; font-family: Verdana, Geneva, sans-serif; text-align:left; line-height:18px"> 
  Hi, <b>{{$names}} </b></p>
    <p align="justify">Here is the verification code you regenerated on the Dunamis Church A-2-Z Platform. It expires after 40mins.<br /><br />
      <b>Verification Code: </b> {{$optCode}} <br><br>

      <p>Please enter the code to continue wih the verification process.</p>
    </p>

    <p align="justify"><b>Note:</b> <b style="color: #ff8a80;">you have generated 1 out of 3 times of your total allowed time to generate this code on the system.</b> <br> Once again, you are welcome to the platform. 
      <br /> 
      <br /> 
      <br />
    <b><i>Pst. Ibrahim Zakariya</i></b> 
    <br>System Administrator 
          </p>
</body>
</html>