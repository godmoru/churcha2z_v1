

<!DOCTYPE html>
<html>
<head>
  <title>
    Location Posting
  </title>
</head>
<body>
  <p style="font-size:14px; text-decoration:none; color:#3a3d41; font-family: Verdana, Geneva, sans-serif; text-align:left; line-height:18px"> 
  Dear, <strong>{{$names}}</strong> </p>
    <p align="justify">Congratulation for your recent posting to your new location. You are by this mail notified that your posting has been effected on DIGC Church A-2-Z Platform. Find below details of your posting. <br /><br />
      <b>Location Posted to: </b> {{$location}} <br /><br /> 
      
    </p>
    <p>You are advised to contact the system administrator for any assistance.</a></p>
    <p align="justify"><b>Note:</b> Note that all access to this platform is no longer available to you for your previous location and has been moved to the new location. <br> Once again, Congratulations. 
      <br /> 
      <br /> 
      <br />
    <b><i>Pst. Ibrahim Zakariya</i></b> 
    <br>System Administrator 
          </p>
</body>
</html>
